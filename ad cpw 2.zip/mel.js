
var tabProd = new Array(5);
var tabTipo = new Array(5);

tabProd[0] = ["Iogurte", 300, 360 ];
tabProd[1] = ["Iogurte Zero", 300, 360 ];
tabProd[2] = ["Balas de Gengibre", 300, 360 ];
tabProd[3] = ["Balas", 300, 360 ];
tabProd[4] = ["Barra de Cereal", 300, 360 ];

tabTipo[0] = [ "IogurteNatMel100" ,"Natural com mel ", "130g",8];
tabTipo[1] = [ "Iogurtezerolac100"," Iogurte zero cal ", "130g",8 ];
tabTipo[2] = [ "BalaGengibre100"," Bala de gengibre com mel ", "120g",10 ];
tabTipo[3] = [ "BalaAnis100"," Bala de anis ", "120g",10 ];
tabTipo[4] = [ "BarraGranAveiaMel100"," Barra de Cereal de Mel e Granola ","60g",5 ]
            

function produto(tipo)
{

var jan = open("", tabProd[tipo][0],"location=no,status=no,width=" +
tabProd[tipo][1] + ",height="+tabProd[tipo][2]+"");

with (jan.document) {
  write("<html><head><title>Lista de Produtos</title>");
  write("<link rel=stylesheet type=text/css href=amigourso.css>");
  write("</head><body>");
  write("<div class='janInfo'>");
  write("<h2>", tabProd[tipo][0], "</h2>");
  write("<img class='janInfoImg' src='Imagens/",
   tabTipo[tipo][0], ".jpg' />");
  write("<ul>");
  write( "Tipo:",tabTipo[tipo][1],"<br>","Qtd:",tabTipo[tipo][2], 
  	    "<br>" ," Preço: R$ ", "<b>", tabTipo[tipo][3], ",00", "</b>") 
  write("</ul>");
              

write("<input type='button' value='Fechar' ");
write("onClick='window.close();'/></div>");
write("</form></div></body></html>");
close();


}
}


var tabInfo = new Array(6) 
var tabDesc = new Array(6)
var tabRs = new Array(6)
{
tabInfo[0] = ["vazio", ];
tabInfo[1] = ["MelSilvestre100"];
tabInfo[2] = ["MelEucalipto100", 2]
tabInfo[3] = ["MelLaranja100",   3]
tabInfo[4] = ["Propol100",       4]
tabInfo[5] = ["Spray100",        5]

tabDesc[0] = ["vazio"];
tabDesc[1] = ["Flor Silvestre 350g"];
tabDesc[2] = ["Eucalipto 450g"];
tabDesc[3] = ["Flor de Laranjeira 750g"];
tabDesc[4] = ["Extrato 30ml"];
tabDesc[5] = ["Spray"];

tabRs[0] = ["0"];
tabRs[1] = ["20"];
tabRs[2] = ["25"];
tabRs[3] = ["40"];
tabRs[4] = ["16"];
tabRs[5] = ["9"];

function tabmostra(ind) {
  var tit = document.getElementById("titDes");
  var pro = document.getElementById("proDes");
  var img = document.getElementById("imgDes");
  
  tit.innerHTML = "<p>" + tabDesc[ind][0];
  img.src ="Imagens/" + tabInfo[ind][0] + ".jpg", tabDesc[ind][0];
  pro.innerHTML = "<p> Preço:<b class='preco'>  R$ " + tabRs[ind][0] + ",00 </b>";
}
}